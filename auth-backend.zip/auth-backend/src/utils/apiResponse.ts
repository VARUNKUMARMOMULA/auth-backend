// apiResponse.ts
export class ApiResponse {
  constructor(
    public statusCode: number,
    public data: any,
    public message = 'Success'
  ) {}

  static success(data: any, message = 'Success') {
    return new ApiResponse(200, data, message);
  }

  static created(data: any, message = 'Created') {
    return new ApiResponse(201, data, message);
  }
}