// auth.service.ts
import bcrypt from 'bcryptjs';
import { generateToken } from '../config/jwt';
import User from '../models/user.model';
import { SignupInput, LoginInput } from '../schemas/auth.schema';
import { ApiError } from '../utils/apiError';
import { ApiResponse } from '../utils/apiResponse';

export const signup = async (input: SignupInput) => {
  const { name, email, password } = input;

  // Check if user already exists
  const existingUser = await User.findOne({ where: { email } });
  if (existingUser) {
    throw new ApiError(409, 'Email already in use');
  }

  // Hash password
  const hashedPassword = await bcrypt.hash(password, 10);

  // Create user
  const user = await User.create({
    name,
    email,
    password: hashedPassword,
  });

  // Generate token
  const token = generateToken({ id: user.id, email: user.email, role: user.role });

  return new ApiResponse(201, { user: { id: user.id, name: user.name, email: user.email, role: user.role }, token });
};

export const login = async (input: LoginInput) => {
  const { email, password } = input;

  // Find user by email
  const user = await User.findOne({ where: { email } });
  if (!user) {
    throw new ApiError(401, 'Invalid credentials');
  }

  // Compare passwords
  const isPasswordValid = await bcrypt.compare(password, user.password);
  if (!isPasswordValid) {
    throw new ApiError(401, 'Invalid credentials');
  }

  // Generate token
  const token = generateToken({ id: user.id, email: user.email, role: user.role });

  return new ApiResponse(200, { user: { id: user.id, name: user.name, email: user.email, role: user.role }, token });
};