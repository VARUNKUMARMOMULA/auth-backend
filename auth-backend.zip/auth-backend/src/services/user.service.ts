// user.service.ts
import User from '../models/user.model';
import { ApiResponse } from '../utils/apiResponse';

export const getCurrentUser = async (userId: number) => {
  const user = await User.findByPk(userId, {
    attributes: { exclude: ['password'] },
  });

  if (!user) {
    throw new ApiError(404, 'User not found');
  }

  return new ApiResponse(200, user);
};