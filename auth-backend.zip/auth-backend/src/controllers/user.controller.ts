// user.controller.ts
import { Request, Response, NextFunction } from 'express';
import { getCurrentUser } from '../services/user.service';

export const getCurrentUserHandler = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const response = await getCurrentUser(req.user.id);
    res.status(response.statusCode).json(response);
  } catch (error) {
    next(error);
  }
};