// auth.controller.ts
import { Request, Response, NextFunction } from 'express';
import { signup, login } from '../services/auth.service';
import { signupSchema, loginSchema } from '../schemas/auth.schema';

export const signupHandler = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const response = await signup(req.body);
    res.status(response.statusCode).json(response);
  } catch (error) {
    next(error);
  }
};

export const loginHandler = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const response = await login(req.body);
    res.status(response.statusCode).json(response);
  } catch (error) {
    next(error);
  }
};