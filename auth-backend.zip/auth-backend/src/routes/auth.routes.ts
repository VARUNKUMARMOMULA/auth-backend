// auth.routes.ts
import express from 'express';
import { signupHandler, loginHandler } from '../controllers/auth.controller';
import { getCurrentUserHandler } from '../controllers/user.controller';
import { signupSchema, loginSchema } from '../schemas/auth.schema';
import { validate } from '../middlewares/validation.middleware';
import { authenticate } from '../middlewares/auth.middleware';

const router = express.Router();

router.post('/signup', validate(signupSchema), signupHandler);
router.post('/login', validate(loginSchema), loginHandler);
router.get('/me', authenticate, getCurrentUserHandler);

export default router;