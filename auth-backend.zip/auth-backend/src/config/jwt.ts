import dotenv from 'dotenv';
import jwt from 'jsonwebtoken';
import { ApiError } from '../utils/apiError';

// Load environment variables
dotenv.config();

// Validate required environment variables
const requiredEnvVars = ['JWT_SECRET', 'JWT_REFRESH_SECRET'];
for (const envVar of requiredEnvVars) {
  if (!process.env[envVar]) {
    throw new Error(`Missing required environment variable: ${envVar}`);
  }
}

// Configuration
const JWT_CONFIG = {
  secret: process.env.JWT_SECRET as string,
  expiresIn: process.env.JWT_EXPIRES_IN || '1d',
  refreshSecret: process.env.JWT_REFRESH_SECRET as string,
  refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d'
};

// Type definitions
interface TokenPayload {
  userId: string | number;
  email: string;
  role?: string;
  [key: string]: any;
}

export const generateAccessToken = (payload: TokenPayload): string => {
  try {
    return jwt.sign(payload, JWT_CONFIG.secret, {
      expiresIn: JWT_CONFIG.expiresIn
    });
  } catch (error) {
    throw new ApiError(500, 'Failed to generate access token');
  }
};

export const generateRefreshToken = (payload: TokenPayload): string => {
  try {
    return jwt.sign(payload, JWT_CONFIG.refreshSecret, {
      expiresIn: JWT_CONFIG.refreshExpiresIn
    });
  } catch (error) {
    throw new ApiError(500, 'Failed to generate refresh token');
  }
};

export const verifyAccessToken = (token: string): TokenPayload => {
  try {
    return jwt.verify(token, JWT_CONFIG.secret) as TokenPayload;
  } catch (error) {
    throw new ApiError(401, 'Invalid or expired access token');
  }
};

export const verifyRefreshToken = (token: string): TokenPayload => {
  try {
    return jwt.verify(token, JWT_CONFIG.refreshSecret) as TokenPayload;
  } catch (error) {
    throw new ApiError(401, 'Invalid or expired refresh token');
  }
};

// Utility function to generate both tokens
export const generateAuthTokens = (payload: TokenPayload) => {
  return {
    accessToken: generateAccessToken(payload),
    refreshToken: generateRefreshToken(payload)
  };
};